import { HomeMonitorPage } from './app.po';

describe('home-monitor App', function() {
  let page: HomeMonitorPage;

  beforeEach(() => {
    page = new HomeMonitorPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
