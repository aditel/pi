import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';

import { ChartsModule } from 'ng2-charts';

// components
import { AppComponent } from './app.component';
import { NavComponent } from './components/nav.component';
import { FooterComponent } from './components/footer.component';
import { TemperatureComponent } from './components/temperature.component';
import { CameraComponent } from './components/camera.component';

// pages
import { TemperaturePageComponent } from './pages/temperature-page.component';
import { CameraPageComponent } from './pages/camera-page.component';  

import { TemperatureService } from './services/temperature.service';

const appRoutes: Routes = [
  { path: '', redirectTo: 'temperature', pathMatch: 'full' },
  { path: 'temperature', component: TemperaturePageComponent },
  { path: 'camera', component: CameraPageComponent },
];

@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    FooterComponent, 
    TemperatureComponent, 
    CameraComponent, 
    TemperaturePageComponent, 
    CameraPageComponent 
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    ChartsModule, 
    RouterModule.forRoot(appRoutes)
  ],
  providers: [TemperatureService],
  bootstrap: [AppComponent]
})

export class AppModule { }
export interface TemperatureSensor {
  s: number;
  t: number;
  h: number;
} 