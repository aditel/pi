import { Component, Input, SimpleChange } from '@angular/core';
import { TemperatureService } from '../services/temperature.service';
import { TemperatureSensor } from '../app.module';
import { Observable } from 'rxjs/Rx';


@Component({
  selector: 'temperature',
  templateUrl: './temperature.component.html',
  styleUrls: ['./temperature.component.scss'],
})
export class TemperatureComponent {

  @Input() sensorId: number;

  public sensorMapping: Object = {
    1: 'Dormitor mare',
    2: 'Living'
  };
  
  public recentData:Array<any> = [{}];
  public recentLabels:Array<any> = [];
  public historicalData:Array<any> = [{}];
  public historicalLabels:Array<any> = [];
  public lastTemperature: number = 0;
  
  public lineChartOptions:any = {
    responsive: true,
    animation: false
  };
  public lineChartColors:Array<any> = [
    { // grey
      backgroundColor: 'rgba(148,159,177,0.2)',
      borderColor: 'rgba(148,159,177,1)',
      pointBackgroundColor: 'rgba(148,159,177,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(148,159,177,0.8)'
    }
  ];
  public lineChartLegend:boolean = false;
  public lineChartType:string = 'line';
  public temperatureClass:string = '';

  constructor(private temperatureService : TemperatureService) {
    var timer = Observable.timer(0, 60000);
    var obj = timer.subscribe(t => {
      this.refresh(this.sensorId);
      // if(self.stopPooling) { obj.unsubscribe(); }
    });       
  }
 
  // events
  public chartClicked(e:any):void {
    console.log(e);
  }
 
  public chartHovered(e:any):void {
    console.log(e);
  }

  ngOnChanges(changes: {[sensorId: number]: SimpleChange}) {
    this.refresh(changes['sensorId'].currentValue);
  }

  private refresh(sensorId: number): void {
    if(!sensorId) {
      return;
    }
    this.temperatureService.getLatestData(sensorId).subscribe(
      data => {
        var currentData = data.map(item => item.t);
        var currentLabels = data.map(item => {
          var date = new Date(item.ts);
          var time = ("0" + date.getHours()).slice(-2) + ":" + ("0" + date.getMinutes()).slice(-2);
          return time;
        });
        this.computeHistoricalData(data, currentLabels);
        this.computeRecentData(currentData, currentLabels);
        this.lastTemperature = currentData[currentData.length - 1];
        this.temperatureClass = (this.lastTemperature < 21 ? 'text-primary' : this.lastTemperature < 26 ? 'text-success' : 'text-danger');
      });
  }

  private computeHistoricalData(data: Array<any>, labels: Array<any>):void {
    var tempData = new Array<any>();
    var tempLabels = new Array<any>();
    var lastHour = new Date(data[data.length - 1].ts).getHours();
    var temperatureSum = 0;
    var temperatureCount = 0;
    var reverseData = data.map(x => Object.assign({}, x)).reverse();
    
    reverseData.forEach(element => {
      var currentHour = new Date(element.ts).getHours();
      if(currentHour != lastHour) {
        tempData.push(temperatureSum / temperatureCount);
        tempLabels.push(("0" + lastHour).slice(-2) + ":..");
        temperatureSum = 0;
        temperatureCount = 0;
      }
      temperatureCount ++;
      temperatureSum += element.t;
      lastHour = currentHour;
    });

    this.historicalData[0].data = tempData.reverse();
    this.historicalLabels = tempLabels.reverse();
  }

  private computeRecentData(data: Array<any>, labels: Array<any>):void {
    var records = Math.min(24, data.length);
    this.recentData[0].data = data.slice(data.length - records + 1, data.length);
    this.recentLabels = labels.slice(data.length - records + 1, data.length);
  }
}
