import { Component } from '@angular/core';

@Component({
  selector: 'camera',
  templateUrl: './camera.component.html',
  styleUrls: ['./camera.component.scss'],
  inputs: [ 'location', 'url' ]
})

export class CameraComponent {
}
