import { Component, OnInit } from '@angular/core';
import { TemperatureService } from './../services/temperature.service'; 
import { TemperatureSensor } from './../app.module';

@Component({
  selector: 'app-temperature-page',
  templateUrl: './temperature-page.component.html',
  styleUrls: ['./temperature-page.component.scss'],
  providers: [ TemperatureService ]
})
export class TemperaturePageComponent implements OnInit {

  temperatureSensors: TemperatureSensor[] = [
  ];

  constructor(private temperatureService : TemperatureService) {
    temperatureService.getSensors().subscribe(
      sensors => this.temperatureSensors = sensors);
  } 
  ngOnInit() {
  }

}
