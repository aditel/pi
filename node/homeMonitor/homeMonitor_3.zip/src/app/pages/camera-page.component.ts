import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-camera-page',
  templateUrl: './camera-page.component.html',
  styleUrls: ['./camera-page.component.scss']
})
export class CameraPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
