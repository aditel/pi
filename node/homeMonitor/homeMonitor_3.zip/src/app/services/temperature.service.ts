import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class TemperatureService {
    constructor(private http: Http) {   
    }

    getSensors() {
        return this.http.get('http://192.168.0.35:8080/getTemperatureSensors').map(res => res.json());
    }

    getLatestData(sid: number) {
        return this.http.get('http://192.168.0.35:8080/getLatestData?sid=' + sid).map(res => res.json());
    }
}
